# Todo list

_\( managed using [todo-md](https://github.com/Hypercubed/todo-md) \)_

- [ ] Compatibility with RequireJS #3
- [ ] Add testing to gruntfile
- [x] Minify?
- [ ] ngmin?